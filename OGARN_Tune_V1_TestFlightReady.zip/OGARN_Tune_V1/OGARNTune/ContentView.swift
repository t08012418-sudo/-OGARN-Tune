import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var selectedTab = 0
    @State private var showingImporter = false
    @State private var fileName = "ยังไม่ได้เลือกไฟล์"
    @State private var map = TuneMap.demo()
    @State private var selectedCell: (Int, Int)? = nil
    @State private var status = "พร้อมใช้งาน"

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.03, green: 0.04, blue: 0.08), Color(red: 0.08, green: 0.04, blue: 0.13)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                header
                if selectedTab == 0 { dashboard }
                else if selectedTab == 1 { mapEditor }
                else { settings }
                bottomBar
            }
        }
        .preferredColorScheme(.dark)
        .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.data, .item], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                if let url = urls.first {
                    fileName = url.lastPathComponent
                    status = "เปิดไฟล์แล้ว: \(fileName)"
                }
            case .failure(let error):
                status = "เปิดไฟล์ไม่สำเร็จ: \(error.localizedDescription)"
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "gauge.with.dots.needle.33percent")
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.cyan)
            VStack(alignment: .leading, spacing: 2) {
                Text("OGARN จูน")
                    .font(.system(size: 21, weight: .black, design: .rounded))
                Text("ECU TUNING TOOL • V1")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Circle()
                .fill(.green)
                .frame(width: 9, height: 9)
            Text("READY")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(.green)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(.ultraThinMaterial)
    }

    private var dashboard: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                banner
                Text("เครื่องมือ")
                    .font(.headline)
                    .padding(.top, 4)
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                    toolCard("ตรวจสอบ ECU", "cpu", .red) { status = "โหมดตรวจสอบ ECU (จำลอง)" }
                    toolCard("วิเคราะห์น้ำมัน", "fuelpump", .cyan) { status = "เปิด Fuel Map"; selectedTab = 1 }
                    toolCard("RACE BOX", "bolt.fill", .purple) { status = "เปิด RACE BOX (จำลอง)" }
                    toolCard("RACE CAM", "video.fill", .purple) { status = "เปิด RACE CAM (จำลอง)" }
                    toolCard("Live Data", "waveform.path.ecg", .green) { status = "Live Data (จำลอง)" }
                    toolCard("Speed GPS", "location.fill", .orange) { status = "GPS (จำลอง)" }
                    toolCard("จูนหัวฉีด", "slider.horizontal.3", .pink) { selectedTab = 1; status = "เปิด Injector Map" }
                    toolCard("ตั้งค่า", "gearshape.fill", .gray) { selectedTab = 2 }
                }
                fileSection
            }
            .padding(16)
        }
    }

    private var banner: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text("LIVE DATA")
                    .font(.system(size: 22, weight: .black, design: .rounded))
                Text("หน้าหลักสำหรับตรวจสอบและปรับค่าจูน")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: "chevron.right.2")
                .font(.title2.bold())
                .foregroundStyle(.cyan)
        }
        .padding(18)
        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.06)))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.cyan.opacity(0.5), lineWidth: 1))
    }

    private var fileSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("ไฟล์จูน")
                .font(.headline)
            HStack {
                Image(systemName: "doc.binary.fill")
                    .foregroundStyle(.cyan)
                VStack(alignment: .leading) {
                    Text(fileName).font(.subheadline.weight(.semibold)).lineLimit(1)
                    Text(status).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                }
                Spacer()
                Button("เปิด BIN") { showingImporter = true }
                    .buttonStyle(.borderedProminent)
                    .tint(.cyan)
            }
            .padding(12)
            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
        }
    }

    private func toolCard(_ title: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: icon)
                    .font(.title3.bold())
                    .foregroundStyle(tint)
                Spacer(minLength: 2)
                Text(title)
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(height: 88)
            .padding(13)
            .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 15))
            .overlay(RoundedRectangle(cornerRadius: 15).stroke(tint.opacity(0.35), lineWidth: 1))
        }
    }

    private var mapEditor: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading) {
                    Text("MAP EDITOR").font(.headline.bold())
                    Text("ตัวอย่างตารางจูน • ยังไม่เขียนลง ECU").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Button { saveMap() } label: {
                    Label("บันทึก", systemImage: "square.and.arrow.down")
                }.buttonStyle(.borderedProminent).tint(.cyan)
            }.padding(14)

            HStack(spacing: 0) {
                Text("RPM / LOAD").frame(width: 82, height: 34).background(Color.white.opacity(0.05))
                ForEach(map.columns, id: \.self) { c in
                    Text(c).frame(minWidth: 67, height: 34).font(.caption2.bold()).background(Color.white.opacity(0.05))
                }
            }

            ScrollView([.horizontal, .vertical]) {
                Grid(horizontalSpacing: 1, verticalSpacing: 1) {
                    ForEach(Array(map.rows.enumerated()), id: \.offset) { r, row in
                        GridRow {
                            Text(row.label).frame(width: 82, height: 42).font(.caption.bold()).background(Color.white.opacity(0.06))
                            ForEach(Array(row.values.enumerated()), id: \.offset) { c, value in
                                Button {
                                    selectedCell = (r, c)
                                    map.rows[r].values[c] = min(20, value + 0.10)
                                } label: {
                                    Text(String(format: "%.2f", value))
                                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                                        .frame(minWidth: 67, minHeight: 42)
                                        .background(cellColor(value))
                                        .foregroundStyle(.white)
                                }
                            }
                        }
                    }
                }
                .padding(8)
            }
            .scrollIndicators(.visible)

            HStack {
                Text("แตะช่องเพื่อเพิ่มค่า +0.10").font(.caption).foregroundStyle(.secondary)
                Spacer()
                Text(status).font(.caption).foregroundStyle(.cyan).lineLimit(1)
            }.padding(.horizontal, 14).padding(.vertical, 10)
        }
    }

    private func cellColor(_ value: Double) -> Color {
        let t = min(max(value / 20.0, 0), 1)
        return Color(red: 0.08 + 0.05*t, green: 0.25 + 0.45*t, blue: 0.55 + 0.35*t)
    }

    private func saveMap() { status = "บันทึก Map แล้ว (โหมดจำลอง)" }

    private var settings: some View {
        Form {
            Section("รถ / ECU") {
                Text("Demo Vehicle")
                Text("Demo ECU — ไม่เชื่อมต่ออุปกรณ์")
            }
            Section("ระบบ") {
                Label("OGARN จูน V1", systemImage: "info.circle")
                Text("BIN/XDF และการสื่อสาร ECU จะเพิ่มในเวอร์ชันถัดไป")
            }
        }
        .scrollContentBackground(.hidden)
    }

    private var bottomBar: some View {
        HStack {
            tab("house.fill", "หน้าหลัก", 0)
            tab("tablecells.fill", "จูน Map", 1)
            tab("gearshape.fill", "ตั้งค่า", 2)
        }
        .padding(.top, 8)
        .padding(.bottom, 5)
        .background(.ultraThinMaterial)
    }

    private func tab(_ icon: String, _ title: String, _ index: Int) -> some View {
        Button { selectedTab = index } label: {
            VStack(spacing: 4) {
                Image(systemName: icon)
                Text(title).font(.caption2)
            }
            .frame(maxWidth: .infinity)
            .foregroundStyle(selectedTab == index ? .cyan : .secondary)
        }
    }
}

struct TuneMap {
    struct Row { var label: String; var values: [Double] }
    var columns: [String]
    var rows: [Row]

    static func demo() -> TuneMap {
        let cols = ["0.8", "1.0", "1.2", "1.4", "1.6", "1.8"]
        let rpms = [800, 1100, 1200, 1500, 1800, 2200, 2600, 3000]
        let rows = rpms.map { rpm in
            Row(label: "\(rpm)", values: cols.enumerated().map { i, _ in 2.80 + Double((rpm/100 + i*3) % 13) * 0.07 })
        }
        return TuneMap(columns: cols, rows: rows)
    }
}
