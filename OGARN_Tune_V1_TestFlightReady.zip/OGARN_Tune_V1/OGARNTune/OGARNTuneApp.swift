import SwiftUI

@main
struct OGARNTuneApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
